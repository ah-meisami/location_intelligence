Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
 by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Fri May  4 05:27:20 UTC 2018
GPS rectangle coordinates (lng,lat): 
Script URL: 
Name of area: 

We appreciate any feedback, suggestions and a donation! You can support us via
PayPal or bank wire transfer: https://www.bbbike.org/community.html

thanks, Wolfram Schneider

--
Your Cycle Route Planner: https://www.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
